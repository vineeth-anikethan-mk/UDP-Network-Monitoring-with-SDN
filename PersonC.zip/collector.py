#!/usr/bin/env python3
"""Centralized UDP monitoring server.
Receives telemetry datagrams, tracks every node, raises application-level alerts
and publishes its view to state.json for the controller and the dashboard."""
import json
import socket
import threading
import time
from collections import deque

import jf_config as C

nodes = {}
lock = threading.Lock()
active = {}          # (node, kind) -> (level, text)


def alert(key, level, text):
    """Log only when an alert appears, changes level, or clears."""
    old = active.get(key)
    if level == "OK":
        if old:
            del active[key]
            C.log_line(C.COLLECTOR_ALERT_LOG, "[COLLECTOR] CLEARED  " + text)
        return
    if old is None or old[0] != level:
        C.log_line(C.COLLECTOR_ALERT_LOG, "[COLLECTOR] %-8s %s" % (level, text))
    active[key] = (level, text)


def receiver(sock):
    while True:
        try:
            data, addr = sock.recvfrom(4096)
        except OSError:
            return
        now = time.time()
        try:
            m = json.loads(data.decode())
            name = str(m["node"])
            seq = int(m["seq"])
            tx = float(m.get("tx_mbps", 0))
            rx = float(m.get("rx_mbps", 0))
            ts = float(m.get("ts", now))
        except (ValueError, KeyError, TypeError, UnicodeDecodeError):
            continue                       # malformed datagram: ignore
        with lock:
            n = nodes.setdefault(name, {"last_seq": None, "last_seen": None, "received": 0,
                                        "lost": 0, "events": deque(), "tx": 0.0, "rx": 0.0,
                                        "delay_ms": 0.0})
            silent = n["last_seen"] is not None and now - n["last_seen"] > C.DOWN_AFTER_SEC
            lost_now = 0
            if n["last_seq"] is not None and seq > n["last_seq"] + 1 and not silent:
                lost_now = seq - n["last_seq"] - 1
            n["last_seq"] = seq
            n["last_seen"] = now
            n["received"] += 1
            n["lost"] += lost_now
            n["events"].append((now, lost_now))
            n["tx"], n["rx"] = tx, rx
            n["delay_ms"] = max(0.0, (now - ts) * 1000.0)


def evaluate_once():
    now = time.time()
    out_nodes = {}
    with lock:
        for name, n in nodes.items():
            while n["events"] and now - n["events"][0][0] > C.LOSS_WINDOW_SEC:
                n["events"].popleft()
            got = len(n["events"])
            lost = sum(e[1] for e in n["events"])
            total = got + lost
            loss_pct = 100.0 * lost / total if total else 0.0
            age = now - n["last_seen"]
            status = "DOWN" if age > C.DOWN_AFTER_SEC else "UP"

            if status == "DOWN":
                alert((name, "down"), "CRITICAL",
                      "%s node DOWN - no telemetry for %.0fs" % (name, age))
                for k in ("tx", "loss", "delay"):
                    active.pop((name, k), None)
            else:
                alert((name, "down"), "OK", "%s node back UP" % name)
                tx = n["tx"]
                if tx >= C.TX_CRIT_MBPS:
                    alert((name, "tx"), "CRITICAL",
                          "%s app-level TX %.1f Mbps >= %.1f" % (name, tx, C.TX_CRIT_MBPS))
                elif tx >= C.TX_WARN_MBPS:
                    alert((name, "tx"), "WARNING",
                          "%s app-level TX %.1f Mbps >= %.1f" % (name, tx, C.TX_WARN_MBPS))
                else:
                    alert((name, "tx"), "OK", "%s app-level TX back to normal" % name)
                if total >= 5 and loss_pct >= C.LOSS_WARN_PCT:
                    alert((name, "loss"), "WARNING",
                          "%s telemetry loss %.0f%% over last %ds" % (name, loss_pct, C.LOSS_WINDOW_SEC))
                else:
                    alert((name, "loss"), "OK", "%s telemetry loss back to normal" % name)
                if n["delay_ms"] >= C.DELAY_WARN_MS:
                    alert((name, "delay"), "WARNING",
                          "%s telemetry delay %.0f ms" % (name, n["delay_ms"]))
                else:
                    alert((name, "delay"), "OK", "%s telemetry delay back to normal" % name)

            out_nodes[name] = {"status": status, "tx_mbps": round(n["tx"], 2),
                               "rx_mbps": round(n["rx"], 2), "loss_pct": round(loss_pct, 1),
                               "delay_ms": round(n["delay_ms"], 1), "received": n["received"],
                               "lost": n["lost"], "age_s": round(age, 1)}
        alerts = ["%s %s" % (lv, tx_) for lv, tx_ in active.values()]
    C.write_json_atomic(C.STATE_FILE, {"updated": now, "nodes": out_nodes, "alerts": alerts})


def main():
    C.ensure_dir()
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", C.TELEMETRY_PORT))
    print("collector listening on UDP %d" % C.TELEMETRY_PORT, flush=True)
    threading.Thread(target=receiver, args=(sock,), daemon=True).start()
    while True:
        evaluate_once()
        time.sleep(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
