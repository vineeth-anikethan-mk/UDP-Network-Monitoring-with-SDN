# Network Monitoring and Alert System (Topic 6, UDP + SDN)

## 1. Problem Statement and Objectives
We build a virtual SDN network where every monitored host periodically reports its own application-level interface health over **UDP** to a centralized monitoring server (`collector.py`), while an **OpenFlow 1.3 SDN controller** (`controller.py`, built on Ryu) polls switch port and flow counters to measure network-level link and port utilisation. By cross-referencing host-reported telemetry with switch-measured traffic statistics, the controller confirms abnormal traffic senders, generates real-time alerts, and automatically quarantines flooding hosts at the switch port level while keeping ARP and UDP telemetry open.

## 2. Architecture and Data Flow

```
            h5 (monitoring server 10.0.0.5, UDP 9999)
             |
   c0 ----- s1 ---------- s3 -- h3, h4
 (Ryu)       |
            s2 -- h1, h2          h1..h4 run telemetry agents
```

| Component | Runs on | Role |
|---|---|---|
| **Shared Configuration** (`jf_config.py`) | All nodes / VM | Centralizes file paths (`/tmp/jackfruit`), network addresses, UDP/OpenFlow ports, polling intervals, abnormality thresholds, and atomic JSON/logging helpers |
| **Telemetry Agents** (`agent.py`) | `h1`, `h2`, `h3`, `h4` | Every 1 s, reads `/proc/net/dev`, computes TX/RX bitrates and packet rates, and sends a JSON datagram over UDP to `h5` (`10.0.0.5:9999`) |
| **Monitoring Server** (`collector.py`) | `h5` (`10.0.0.5:9999`) | Receives UDP telemetry from all agents, tracks per-node sequence numbers, packet loss, one-way delay, Liveness (`UP`/`DOWN`), and TX rate alerts, publishing to `/tmp/jackfruit/state.json` |
| **SDN Controller** (`controller.py`) | VM (OpenFlow 1.3, port `6653`) | Acts as a learning switch, polls port/flow stats every 2 s, combines switch utilisation with `state.json`, logs alerts, and installs/removes quarantine flow rules |
| **Live Dashboard** (`dashboard.py`) | VM terminal | Merges `/tmp/jackfruit/state.json` and `/tmp/jackfruit/net_state.json` every 1 s into a live unified terminal view |
| **Mininet Topology** (`topo.py`) | VM (`sudo`) | Builds 3 OpenFlow 1.3 switches (`s1`–`s3`) and 5 hosts (`h1`–`h5`) connected by 10 Mbps `TCLink` links, starts `collector.py` and `agent.py`, and provides the `agent` CLI command |

---

## 3. UDP Socket Design (Person A)

### 3.1 Why UDP for Telemetry
Telemetry reports are small, periodic, real-time status updates sent every `SEND_INTERVAL = 1.0` second. Using connectionless UDP (`socket.AF_INET, socket.SOCK_DGRAM`) avoids TCP connection setup/teardown overhead, head-of-line blocking, and retransmission storms during network congestion. Because each datagram carries the latest instantaneous rate snapshot, an older lost packet does not need to be retransmitted; instead, missing datagrams directly serve as an indicator of network or agent packet loss.

### 3.2 Message Format
Each telemetry datagram sent by `agent.py` via `sock.sendto()` is a UTF-8 encoded JSON object:

```json
{
  "node": "h1",
  "seq": 42,
  "ts": 1730000000.123,
  "iface": "h1-eth0",
  "tx_mbps": 0.012,
  "rx_mbps": 0.008,
  "tx_pps": 14.0,
  "rx_pps": 10.0
}
```

- **`node`**: Host identifier (`h1`–`h4`).
- **`seq`**: Monotonically increasing integer sequence number starting at `1`.
- **`ts`**: Floating-point Unix timestamp (`time.time()`) when the counter sample was taken.
- **`iface`**: First non-loopback network interface read from `/proc/net/dev`.
- **`tx_mbps` / `rx_mbps`**: Transmit and receive throughput in Mbps over the last interval:
  $$\text{Rate (Mbps)} = \frac{(\text{bytes}_{\text{now}} - \text{bytes}_{\text{prev}}) \times 8}{\Delta t \times 10^6}$$
- **`tx_pps` / `rx_pps`**: Transmit and receive packet rates in packets per second.

### 3.3 Sequence Numbers, Loss Detection, and Delay Calculation
1. **Sequence Gap Detection**: In `agent.py`, `seq` increments on every 1 s cycle *before* checking the simulated `--drop` probability. When datagrams are dropped in transit (or via `--drop`), the next arriving packet at `collector.py` has `seq > last_seq + 1`. Provided the node was not previously silent for more than `DOWN_AFTER_SEC` (5 s), the collector records `lost_now = seq - last_seq - 1`.
2. **Sliding-Window Loss Percentage**: Each received datagram appends `(now, lost_now)` to a per-node `collections.deque`. During `evaluate_once()`, events older than `LOSS_WINDOW_SEC = 10` seconds are evicted from the left of the deque. Loss percentage over the 10 s window is:
   $$\text{Loss \%} = \frac{\sum \text{lost}}{\text{received} + \sum \text{lost}} \times 100\%$$
   If at least 5 datagrams were expected in the window and $\text{Loss \%} \ge 20\%$, the collector raises a `WARNING` alert.
3. **One-Way Telemetry Delay**: Because all Mininet hosts share the same Linux kernel clock, one-way delay is calculated directly as:
   $$\text{Delay (ms)} = \max(0.0, (\text{now} - \text{ts}) \times 1000)$$
   If delay reaches `DELAY_WARN_MS = 300.0` ms, a `WARNING` alert is logged.
4. **Node Liveness (`UP` / `DOWN`)**: If `now - last_seen > DOWN_AFTER_SEC` (5 s), `collector.py` marks the node `DOWN`, raises a `CRITICAL` alert, and clears stale rate/loss/delay alerts for that host until a new datagram arrives.

### 3.4 Concurrency, Threading, and Error Handling
- **Two-Thread Collector Architecture**:
  - **Receiver daemon thread (`receiver`)**: Blocks on `sock.recvfrom(4096)` so incoming UDP datagrams from multiple hosts are drained immediately from the socket buffer without waiting for the evaluation timer.
  - **Main evaluation loop (`evaluate_once`)**: Runs every 1 s to prune sliding windows, evaluate thresholds (`DOWN`, `TX_WARN_MBPS = 5.0`, `TX_CRIT_MBPS = 7.0`, `LOSS_WARN_PCT = 20.0`, `DELAY_WARN_MS = 300.0`), log state transitions, and write `/tmp/jackfruit/state.json`.
  - **Thread Synchronization**: A shared `threading.Lock()` protects the `nodes` dictionary so the receiver thread and evaluation loop never race on per-node state.
- **Fault Tolerance & Atomic State Publishing**:
  - **Malformed Datagrams**: `receiver()` wraps JSON parsing and key extraction in `try ... except (ValueError, KeyError, TypeError, UnicodeDecodeError)` and silently ignores corrupted packets without crashing the server.
  - **Network Outages on Agent**: `agent.py` catches `OSError` around `sock.sendto()` so if an interface or link goes down, the agent keeps running and resumes reporting once connectivity is restored.
  - **Atomic File Writes**: `write_json_atomic()` writes JSON to `state.json.tmp` and calls `os.replace()` to atomically swap the file, ensuring `controller.py` and `dashboard.py` never read a half-written JSON file.
  - **Edge-Triggered Alert Logging**: `alert()` tracks active `(node, kind)` alerts and only writes to `alerts_collector.log` when an alert first appears, changes severity level, or clears (`OK`).

---

## 4. How to Run & Test (Person A Standalone & Full Integration)

### 4.1 Standalone UDP Socket Test (No Mininet Required)
Open 4 terminals in the project directory on the VM:

```bash
# Terminal 1: Start centralized UDP monitoring server
python3 collector.py

# Terminal 2: Start normal agent h1
python3 agent.py --name h1 --server 127.0.0.1

# Terminal 3: Start agent h2 with 50% simulated telemetry loss
python3 agent.py --name h2 --server 127.0.0.1 --drop 0.5

# Terminal 4: Open live terminal dashboard
python3 dashboard.py
```

### 4.2 Full Mininet + Ryu Smoke Test
```bash
# Terminal 1: Controller
sudo mn -c; sudo rm -rf /tmp/jackfruit
ryu-manager --ofp-tcp-listen-port 6653 controller.py

# Terminal 2: Mininet Topology + Agents + Collector
sudo python3 topo.py

# Terminal 3: Live Dashboard
python3 dashboard.py

# Terminal 4: Live Alert Logs
tail -F /tmp/jackfruit/alerts_controller.log /tmp/jackfruit/alerts_collector.log
```

### 4.3 Experiment E4 Commands (Person A — Robustness & Challenging Scenarios)
At the `mininet>` prompt while the system is idle:

| Scenario | Mininet CLI Commands | Expected Behavior |
|---|---|---|
| **Telemetry Packet Loss (40%)** | `agent h1 0.4` (wait 15 s) $\rightarrow$ `agent h1 0` | `[COLLECTOR] WARNING h1 telemetry loss ...` followed by `CLEARED` after reset |
| **Link Failure (`s1`–`s3`)** | `link s1 s3 down` (wait 10 s) $\rightarrow$ `link s1 s3 up` | Controller logs `CRITICAL LINK DOWN` on `s1`/`s3` port 3; collector marks `h3` & `h4` `DOWN` after ~5 s; both recover on `up` |
| **Node / Agent Failure (`h2`)** | `h2 pkill -f "agent.py --name h2"` (wait 8 s) $\rightarrow$ `agent h2 0` | Collector logs `CRITICAL h2 node DOWN - no telemetry for 5s`, then `CLEARED h2 node back UP` |
