#!/usr/bin/env python3
"""Terminal dashboard: merges collector (application) and controller (network) state."""
import time

import jf_config as C


def f(v, spec="{:.1f}"):
    return "-" if v is None else spec.format(v)


def render():
    app = C.read_json(C.STATE_FILE) or {}
    net = C.read_json(C.NET_STATE_FILE) or {}
    now = time.time()
    app_ok = bool(app) and now - app.get("updated", 0) < 5
    net_ok = bool(net) and now - net.get("updated", 0) < 6
    out = [time.strftime("=== SDN NETWORK MONITOR  %H:%M:%S ===")]
    out.append("collector: %s   controller: %s   mitigation: %s" % (
        "running" if app_ok else "NOT RUNNING", "running" if net_ok else "NOT RUNNING",
        ("ON" if net.get("mitigation") else "OFF") if net_ok else "-"))
    out.append("")
    out.append("%-5s %-5s %6s %6s %6s %7s | %6s %6s %6s  %s" % (
        "NODE", "APP", "TX", "RX", "LOSS%", "DLY ms", "SW-IN", "SW-OUT", "UTIL%", "NET-STATE"))
    app_nodes = app.get("nodes", {})
    net_hosts = net.get("hosts", {})
    for name in sorted(set(app_nodes) | set(net_hosts)):
        n = app_nodes.get(name, {})
        h = net_hosts.get(name, {})
        state = h.get("level", "-") + (" QUARANTINED" if h.get("quarantined") else "")
        out.append("%-5s %-5s %6s %6s %6s %7s | %6s %6s %6s  %s" % (
            name, n.get("status", "-"), f(n.get("tx_mbps")), f(n.get("rx_mbps")),
            f(n.get("loss_pct"), "{:.0f}"), f(n.get("delay_ms"), "{:.0f}"),
            f(h.get("ingress_mbps")), f(h.get("egress_mbps")), f(h.get("util_in_pct"), "{:.0f}"), state))
    out.append("")
    links = net.get("links", {})
    out.append("LINKS: " + (" | ".join("%s %.0f%% (%.1f Mbps)" % (k, v["util_pct"], v["mbps"])
                                       for k, v in sorted(links.items())) or "-"))
    out.append("QUARANTINED: " + (", ".join(net.get("quarantined", [])) or "-"))
    for dpid, flows in sorted(net.get("top_flows", {}).items()):
        busy = ["%s->%s %.2f Mbps" % (x["src"], x["dst"], x["mbps"]) for x in flows if x["mbps"] > 0.05]
        if busy:
            out.append("FLOWS s%s: %s  (entries: %s)" % (dpid, ", ".join(busy),
                                                         net.get("flow_entries", {}).get(str(dpid), "?")))
    out.append("")
    out.append("ACTIVE ALERTS:")
    alerts = app.get("alerts", []) + net.get("alerts", [])
    out.extend("  " + a for a in alerts) if alerts else out.append("  none")
    return "\n".join(out)


def main():
    while True:
        print("\033[2J\033[H" + render(), flush=True)
        time.sleep(1)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
