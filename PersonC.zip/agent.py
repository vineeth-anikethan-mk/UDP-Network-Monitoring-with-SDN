#!/usr/bin/env python3
"""UDP telemetry agent - runs on every monitored host.
Sends one JSON datagram per interval to the monitoring server."""
import argparse
import json
import random
import socket
import time

import jf_config as C


def read_counters():
    """(iface, rx_bytes, rx_packets, tx_bytes, tx_packets) of first non-loopback interface."""
    with open("/proc/net/dev") as f:
        lines = f.readlines()[2:]
    for line in lines:
        name, data = line.split(":", 1)
        if name.strip() == "lo":
            continue
        v = data.split()
        return name.strip(), int(v[0]), int(v[1]), int(v[8]), int(v[9])
    return "none", 0, 0, 0, 0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--name", required=True)
    ap.add_argument("--server", default=C.SERVER_IP)
    ap.add_argument("--port", type=int, default=C.TELEMETRY_PORT)
    ap.add_argument("--interval", type=float, default=C.SEND_INTERVAL)
    ap.add_argument("--drop", type=float, default=0.0,
                    help="probability (0-1) of NOT sending a datagram (simulates telemetry loss)")
    args = ap.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    _, rb0, rp0, tb0, tp0 = read_counters()
    last = time.time()
    seq = 0
    while True:
        time.sleep(args.interval)
        now = time.time()
        iface, rb, rp, tb, tp = read_counters()
        dt = max(now - last, 1e-6)
        seq += 1
        msg = {
            "node": args.name, "seq": seq, "ts": now, "iface": iface,
            "tx_mbps": round((tb - tb0) * 8 / dt / 1e6, 3),
            "rx_mbps": round((rb - rb0) * 8 / dt / 1e6, 3),
            "tx_pps": round((tp - tp0) / dt, 1),
            "rx_pps": round((rp - rp0) / dt, 1),
        }
        last, rb0, rp0, tb0, tp0 = now, rb, rp, tb, tp
        if random.random() < args.drop:
            continue                       # seq still advanced -> collector sees a gap
        try:
            sock.sendto(json.dumps(msg).encode(), (args.server, args.port))
        except OSError:
            pass                           # network down: keep running


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        pass
